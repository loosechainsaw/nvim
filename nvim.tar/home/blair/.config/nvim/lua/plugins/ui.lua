local M = {
    {
        "nvimdev/dashboard-nvim",
        event = "VimEnter",
        config = function()
            require("dashboard").setup({
                theme = "hyper",
                config = {
                    week_header = {
                        enable = true,
                    },
                    shortcut = {
                        { desc = "󰊳 Update", group = "@property", action = "Lazy update", key = "u" },
                        {
                            icon = " ",
                            icon_hl = "@variable",
                            desc = "Files",
                            group = "Label",
                            action = "Telescope find_files",
                            key = "f",
                        },
                    },
                },
            })
        end,
        dependencies = { { "nvim-tree/nvim-web-devicons" } },
    },
    {
        "folke/which-key.nvim",
        event = "VeryLazy",
        init = function()
            vim.o.timeout = true
            vim.o.timeoutlen = 400
        end,
        config = function()
            local wk = require("which-key")

            wk.setup({
                plugins = {
                    marks = true,
                    registers = true,
                    spelling = {
                        enabled = true,
                        suggestions = 20,
                    },
                    presets = {
                        operators = false,
                        motions = true,
                        text_objects = true,
                        windows = true,
                        nav = true,
                        z = true,
                        g = true,
                    },
                },
                ignore_missing = true,
                triggers = "auto",
                triggers_blacklist = {
                    i = { "j", "k" },
                    v = { "j", "k" },
                },
            })

            local opts = {
                mode = "n",
                prefix = "<leader>",
                buffer = nil,
                silent = true,
                noremap = true,
                nowait = true,
            }

            local mappings = {
                ["p"] = { "<cmd>bprev<CR>", "Previous Buffer" },
                ["n"] = { "<cmd>bnext<CR>", "Next Buffer" },
                ["k"] = { "<cmd>bwipeout!<CR>", "Kill Buffer" },
                ["w"] = { "<cmd>w!<CR>", "Save Buffer" },
                ["s"] = { "<cmd>ClangdSwitchSourceHeader<CR>", "Toggle Source / Header" },
                ["<leader-space>"] = {
                    function()
                        vim.lsp.signature_help()
                    end,
                    "Toggle Source / Header",
                },
            }

            wk.register(mappings, opts)

            wk.register({
                ["<leader>"] = {
                    -- CMake mappings
                    c = {
                        name = "CMake",
                        g = { "<cmd>CMakeGenerate<cr>", "Generate" },
                        c = { "<cmd>CMakeClean<cr>", "Clean" },
                        b = { "<cmd>CMakeBuild<cr>", "Build" },
                        r = { "<cmd>CMakeRun<cr>", "Run" },
                        t = { "<cmd>CMakeSelectBuildTarget<cr>", "Select Build Target" },
                    },
                    -- DAP mappings
                    d = {
                        name = "DAP",
                        t = { "<cmd>DapToggleBreakpoint<cr>", "Toggle Breakpoint" },
                        c = { "<cmd>DapContinue<cr>", "Continue" },
                        s = { "<cmd>DapStepInto<cr>", "Step Into" },
                        n = { "<cmd>DapStepOver<cr>", "Step Over" },
                        f = { "<cmd>DapStepOut<cr>", "Step Out" },
                    },
                    -- Telescope mappings
                    f = {
                        name = "Find",
                        f = { "<cmd>Telescope find_files<cr>", "Find File" },
                        b = { "<cmd>Telescope buffers<cr>", "Find Buffer" },
                        r = { "<cmd>Telescope oldfiles<cr>", "Open Recent File" },
                    },
                    -- Git mappings
                    g = {
                        name = "Git",
                        a = { "Git add", "Git Add" },
                        b = { "<cmd>Git blame<cr>", "Git Blame" },
                        c = { "<cmd>Git commit<cr>", "Git Commit" },
                        br = { "<cmd>Git branch<cr>", "Git Branch" },
                        r = { "<cmd>Git pull<cr>", "Git Pull" },
                        p = { "<cmd>Git push<cr>", "Git Push" },
                        d = { "<cmd>Git diff<cr>", "Git Add" },
                        l = { "<cmd>Git log<cr>", "Git Log" },
                        s = { "<cmd>Git status<cr>", "Git Status" },
                    },
                    o = {
                        name = "Overseer",
                        r = { "<cmd>OverseerRun<cr>", "Run" },
                        t = { "<cmd>OverseerToggle<cr>", "Toggle" },
                        c = { "<cmd>OverseerClose<cr>", "Close" },
                    },

                    -- Nvim Tree mappings
                    t = {
                        name = "Nvim Tree",
                        t = { "<cmd>NvimTreeToggle<cr>", "Toggle" },
                        c = { "<cmd>NvimTreeClose<cr>", "Close" },
                        o = { "<cmd>NvimTreeOpen<cr>", "Open" },
                    },
                    -- LSP
                    l = {
                        name = "LSP",
                        a = {
                            function()
                                vim.lsp.buf.code_action()
                            end,
                            "Code Actions",
                        },
                        d = { "<cmd>Telescope lsp_definitions<cr>", "Definition" },
                        q = {
                            function()
                                vim.lsp.buf.code_action({
                                    filter = function(a)
                                        return a.isPreferred
                                    end,
                                    apply = true,
                                })
                            end,
                            "Quick Fix",
                        },
                        r = { "<cmd>Telescope lsp_references<cr>", "References" },
                    },
                    -- Refactoring
                    r = {
                        name = "Refactoring",
                        v = { "<cmd>Refactor extract_var<cr>", "Extract Varaible" },
                        i = { "<cmd>Refactor inline_var<cr>", "Inline Var" },
                        I = { "<cmd>Refactor inline_func<cr>", "Inline Function" },
                    },
                    -- window
                    w = {
                        name = "Window",
                        c = { "<C-w>w<CR>", "Cycle" },
                        j = { "<C-w>j<CR>", "Down" },
                        k = { "<C-w>k<CR>", "Up" },
                        h = { "<C-w>h<CR>", "Left" },
                        l = { "<C-w>l<CR>", "Right" },
                        v = { "<cmd>vsplit<CR>", "Veritical Split" },
                    },
                    -- Space base
                    -- comments
                    z = {
                        name = "Comments",
                        l = {
                            function()
                                require("Comment.api").toggle.linewise.current()
                            end,
                            "Toggle Line",
                        },
                    },
                },
            })

            wk.register({
                r = {
                    name = "Refactoring", -- optional group name
                    b = { "<cmd>Refactor extract_block<cr>", "Extract Block" },
                    B = { "<cmd>Refactor extract_block_to_file<cr>", "Extract Block to File" },
                    e = { "<cmd>Refactor extract<cr>", "Extract Function" },
                    f = { "<cmd>Refactor extract_to_file<cr>", "Extract Function to File" },
                },
            }, { prefix = "<leader>", mode = "v" })

            wk.register({
                z = {
                    name = "Comments", -- optional group name
                    b = {
                        function()
                            local esc = vim.api.nvim_replace_termcodes("<ESC>", true, false, true)
                            vim.api.nvim_feedkeys(esc, "nx", false)
                            require("Comment.api").toggle.blockwise(vim.fn.visualmode())
                        end,
                        "Toggle Block",
                    },
                },
            }, { prefix = "<leader>", mode = "v" })
        end,
    },
    {
        "nvim-tree/nvim-tree.lua",
        dependencies = "nvim-tree/nvim-web-devicons",

        config = function()
            require("nvim-tree").setup({
                sort = {
                    sorter = "case_sensitive",
                },
                view = {
                    width = 30,
                },
                renderer = {
                    full_name = true,
                    group_empty = true,
                    special_files = {},
                    symlink_destination = false,
                    indent_markers = {
                        enable = true,
                    },
                },
                filters = {
                    custom = {
                        "^.git$",
                    },
                },
                actions = {
                    change_dir = {
                        enable = false,
                        restrict_above_cwd = true,
                    },
                    open_file = {
                        resize_window = true,
                        window_picker = {
                            chars = "aoeui",
                        },
                    },
                    remove_file = {
                        close_window = false,
                    },
                },
                update_focused_file = {
                    enable = true,
                    update_root = true,
                    ignore_list = { "help" },
                },
                diagnostics = {
                    enable = true,
                    show_on_dirs = true,
                },
                log = {
                    enable = false,
                    truncate = true,
                    types = {
                        all = false,
                        config = false,
                        copy_paste = false,
                        diagnostics = false,
                        git = false,
                        profile = false,
                        watcher = false,
                    },
                },
            })
        end,
    },
    {
        "akinsho/bufferline.nvim",
        version = "*",
        dependencies = "nvim-tree/nvim-web-devicons",
        config = function()
            require("bufferline").setup({
                options = {
                    theme = true,
                    diagnostics = "nvim_lsp",
                    seperator_style = "slant",
                    mode = "buffers",
                    offsets = {
                        { filetype = "NvimTree" },
                    },
                },
            })
        end,
    },
    {
        "akinsho/toggleterm.nvim",
        version = "*",
        config = function()
            require("toggleterm").setup({
                open_mapping = [[<c-t>]], -- keybinding
                hide_numbers = true, -- hide the number column in toggleterm buffers
                autochdir = false, -- when neovim changes it current directory the terminal will change it's own when next it's opened
                shade_terminals = false, -- NOTE: this option takes priority over highlights specified so if you specify Normal highlights you should set this to false
                insert_mappings = true, -- whether or not the open mapping applies in insert mode
                start_in_insert = false,
                terminal_mappings = true, -- whether or not the open mapping applies in the opened terminals
                persist_size = true,
                persist_mode = true, -- if set to true (default) the previous terminal mode will be remembered
                direction = "horizontal",
                close_on_exit = true, -- close the terminal window when the process exits
                -- Change the default shell. Can be a string or a function returning a string
                shell = vim.o.shell,
                auto_scroll = true, -- automatically scroll to the bottom on terminal output
            })
        end,
    },
    {
        "nvim-lualine/lualine.nvim",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
            require("lualine").setup()
        end,
    },
    {
        "nvim-telescope/telescope-fzf-native.nvim",
        build = "cmake -S. -Bbuild -DCMAKE_BUILD_TYPE=Release && cmake --build build --config Release && cmake --install build --prefix build",
    },
    {
        "nvim-telescope/telescope.nvim",
        tag = "0.1.6",
        dependencies = { "nvim-lua/plenary.nvim" },
        config = function()
            require("telescope").setup({
                defaults = {
                    file_ignore_patterns = { "node_modules/*", "build/*", "out/*", ".git/*" },
                },
                extensions = {
                    fzf = {
                        fuzzy = true, -- false will only do exact matching
                        override_generic_sorter = true, -- override the generic sorter
                        override_file_sorter = true, -- override the file sorter
                        case_mode = "smart_case", -- or "ignore_case" or "respect_case"
                        -- the default case_mode is "smart_case"
                    },
                },
            })
            -- To get fzf loaded and working with telescope, you need to call
            -- load_extension, somewhere after setup function:
            require("telescope").load_extension("fzf")
        end,
    },
    {
        "stevearc/dressing.nvim",
        config = function()
            require("dressing").setup({
                input = {
                    enabled = true,
                    default_prompt = "Input: ",
                    trim_prompt = true,
                    title_pos = "left",
                    insert_only = true,
                    relative = "cursor",
                },
                select = {
                    enabled = true,
                    backend = { "telescope", "builtin" },
                },
            })
        end,
    },
}

return M
