local M = {
    {
        "lukas-reineke/indent-blankline.nvim",
        main = "ibl",
        tags = "v3.5.4",
        version = "v3.5.4",
        opts = {},
        config = function()
            require("ibl").setup({
                indent = {
                    char = "▏", -- This is a slightly thinner char than the default one, check :help ibl.config.indent.char
                },
                scope = {
                    show_start = false,
                    show_end = false,
                },
                exclude = {
                    filetypes = {
                        "dashboard",
                        "terminal",
                    },
                },
            })

            -- disable indentation on the first level
            local hooks = require("ibl.hooks")
            hooks.register(hooks.type.WHITESPACE, hooks.builtin.hide_first_space_indent_level)
            hooks.register(hooks.type.WHITESPACE, hooks.builtin.hide_first_tab_indent_level)
        end,
    },
    {
        "numToStr/Comment.nvim",
        config = function()
            require("Comment").setup({
                ---Add a space b/w comment and the line
                padding = true,
                ---Whether the cursor should stay at its position
                sticky = true,
                ---Lines to be ignored while (un)comment
                ignore = nil,
                mappings = {
                    ---Operator-pending mapping; `zcc` zgbc` `zc[count]{motion}` `zb[count]{motion}`
                    basic = true,
                    ---Extra mapping; `zco`, `zcO`, `zcA`
                    extra = true,
                },
                ---Function to call before (un)comment
                pre_hook = nil,
                ---Function to call after (un)comment
                post_hook = nil,
            })
        end,
    },
    {
        "tpope/vim-fugitive",
    },
}

return M
