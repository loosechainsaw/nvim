local M = {
    {
        "stevearc/overseer.nvim",
        config = function()
            require("overseer").setup({
                templates = { "builtin", "user.run_script", "user.cpp_build" },
            })
        end,
    },
    {
        "jay-babu/mason-nvim-dap.nvim",
        dependencies = {
            "rcarriga/nvim-dap-ui",
            "theHamsta/nvim-dap-virtual-text",
            "mfussenegger/nvim-dap",
            "nvim-neotest/nvim-nio",
        },
        config = function()
            require("mason-nvim-dap").setup({
                ensure_installed = { "stylua", "jq" },
            })

            local dap = require("dap")
            dap.adapters.cppdbg = {
                type = "executable",
                command = vim.fn.stdpath("data") .. "/mason/bin/OpenDebugAD7",
            }

            dap.configurations.cpp = {
                {
                    name = "Launch",
                    type = "cppdbg",
                    request = "launch",
                    MIMode = "lldb",
                    program = function()
                        return vim.fn.input("Executable Path: ", vim.fn.getcwd(), "file")
                    end,
                    cwd = "${workspaceFolder}",
                    stopOnEntry = true,
                    args = function()
                        local args_string = vim.fn.input("Program Args: ")
                        return vim.fn.split(args_string, " ")
                    end,
                },
            }

            dap.configurations.c = dap.configurations.cpp
            dap.configurations.rust = dap.configurations.cpp

            local dapui = require("dapui")
            dapui.setup({
                controls = {
                    element = "repl",
                    enabled = true,
                },
            })

            dap.listeners.after.event_initialized["dapui_config"] = function()
                dapui.open()
            end
            dap.listeners.before.event_terminiated["dapui_config"] = function()
                dapui.close()
            end
            dap.listeners.before.event_exited["dapui_config"] = function()
                dapui.close()
            end
        end,
    },
    {
        "Civitasv/cmake-tools.nvim",
        config = function()
            local osys = require("cmake-tools.osys")
            require("cmake-tools").setup({
                cmake_command = "cmake", -- this is used to specify cmake command path
                ctest_command = "ctest", -- this is used to specify ctest command path
                cmake_regenerate_on_save = true, -- auto generate when save CMakeLists.txt
                cmake_generate_options = { "-DCMAKE_EXPORT_COMPILE_COMMANDS=1" }, -- this will be passed when invoke `CMakeGenerate`
                cmake_build_options = {}, -- this will be passed when invoke `CMakeBuild`
                cmake_build_directory = "build/${variant:buildType}",
                cmake_soft_link_compile_commands = true, -- this will automatically make a soft link from compile commands file to project root dir
                cmake_compile_commands_from_lsp = false, -- this will automatically set compile commands file location using lsp, to use it, please set `cmake_soft_link_compile_commands` to false
                cmake_kits_path = nil, -- this is used to specify global cmake kits path, see CMakeKits for detailed usage
                cmake_variants_message = {
                    short = { show = true }, -- whether to show short message
                    long = { show = true, max_length = 40 }, -- whether to show long message
                },
                cmake_executor = { -- executor to use
                    name = "overseer", -- name of the executor
                    opts = {}, -- the options the executor will get, possible values depend on the executor type. See `default_opts` for possible values.
                    default_opts = { -- a list of default and possible values for executors
                        overseer = {
                            new_task_opts = {
                                strategy = {
                                    "toggleterm",
                                    direction = "horizontal",
                                    autos_croll = true,
                                    quit_on_exit = "success",
                                },
                            }, -- options to pass into the `overseer.new_task` command
                            on_new_task = function(task)
                                require("overseer").open({ enter = false, direction = "right" })
                            end, -- a function that gets overseer.Task when it is created, before calling `task:start`
                        },
                    },
                },
                cmake_runner = { -- runner to use
                    name = "overseer", -- name of the runner
                    opts = {}, -- the options the runner will get, possible values depend on the runner type. See `default_opts` for possible values.
                    default_opts = { -- a list of default and possible values for runners
                        overseer = {
                            new_task_opts = {
                                strategy = {
                                    "toggleterm",
                                    direction = "horizontal",
                                    autos_croll = true,
                                    quit_on_exit = "success",
                                },
                            }, -- options to pass into the `overseer.new_task` command
                            on_new_task = function(task) end, -- a function that gets overseer.Task when it is created, before calling `task:start`
                        },
                    },
                },
                cmake_notifications = {
                    runner = { enabled = true },
                    executor = { enabled = true },
                    spinner = { "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏" }, -- icons used for progress display
                    refresh_rate_ms = 100, -- how often to iterate icons
                },
                cmake_virtual_text_support = false, -- Show the target related to current file using virtual text (at right corner)
            })
        end,
    },
}

return M
