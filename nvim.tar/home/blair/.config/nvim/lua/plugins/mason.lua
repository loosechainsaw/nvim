local M = {
    "williamboman/mason.nvim",
    config = function()
        require("mason").setup()
    end
}

return M
