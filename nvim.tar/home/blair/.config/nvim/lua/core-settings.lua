local function config(ctx, opts)
    for k, v in pairs(opts) do
        ctx.opt[k] = v
    end
end

local M = {
    setup = function()
        config(vim, {
            showmatch = true,
            ignorecase = true,
            mouse = "a",
            hlsearch = false,
            incsearch = true,
            softtabstop = 4,
            expandtab = true,
            shiftwidth = 4,
            number = true,
            relativenumber = true,
            cursorline = true,
            ttyfast = true,
            encoding = "utf-8",
            backup = false,
            writebackup = false,
            signcolumn = "yes",
            updatetime = 300
        })

        vim.g.mapleader = ";"
        vim.g.maplocalleader = ";"
        vim.g.loaded_netrw = 1
        vim.g.loaded_netrwPlugin = 1
    end
}

return M
