return {
    name = "run script",
    builder = function()
        local file = vim.fn.expand("%:p")
        local cmd = { "rm -rf " .. file .. "./build" }
        return {
            cmd = cmd,
            components = {
                "default",
            },
        }
    end,
    condition = {},
}
