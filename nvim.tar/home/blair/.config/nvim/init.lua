-- Setup core nvim settings
require("core-settings").setup()

-- Lazy module loader configuration
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"

if not (vim.uv or vim.loop).fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "https://github.com/folke/lazy.nvim.git",
        "--branch=stable", -- latest stable release
        lazypath,
    })
end

vim.opt.rtp:prepend(lazypath)

-- import modules
    require("lazy").setup({
    require("plugins/theme"),
    require("plugins/ui"),
    require("plugins/mason"),
    require("plugins/lsp-config"),
    require("plugins/build"),
    require("plugins/editor"),
})
