
#include <iostream>

namespace foo {

template <typename T> class customer {
public:
private:
};

} // namespace foo

int main(int argc, char **argv) { return 0; }
